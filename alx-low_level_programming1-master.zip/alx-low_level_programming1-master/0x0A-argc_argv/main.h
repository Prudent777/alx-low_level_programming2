int _putchar(char c);
int check_num(char *str);
