General
What are function pointers and how to use them
What does a function pointer exactly hold
Where does a function pointer point to in the virtual memory
