#include <stdio.h>
/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)

{
int i; /*Decarling statement*/

/*for count 0-9*/
for (i = 0 ; i < 10; i++)
{
printf("%i", i); /*print i*/
}

printf("\n"); /*new line*/

return (0);

}
