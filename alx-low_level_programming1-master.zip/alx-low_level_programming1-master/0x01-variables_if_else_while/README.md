task for variable learning
