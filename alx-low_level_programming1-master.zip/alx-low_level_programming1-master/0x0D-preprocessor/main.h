#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include "0-object_like_macro.h"
#include "1-pi.h"
#include "3-function_like_macro.h"
#include "4-sum.h"

#endif 
