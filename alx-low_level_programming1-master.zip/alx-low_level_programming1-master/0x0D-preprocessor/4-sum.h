#ifndef _SUM_X_
#define _SUM_X_
#define SUM(x, y) ((x) + (y))
#endif
