General
What are macros and how to use them
What are the most common predefined macros
How to include guard your header files
