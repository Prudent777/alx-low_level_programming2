redoing this from the begining
