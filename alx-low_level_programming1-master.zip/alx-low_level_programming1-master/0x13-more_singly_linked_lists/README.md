A set of projects dealing with more singly linked lists
