This is more about pointers and arrays here we discuss the 2 dimensional arrays and many more will come later.
