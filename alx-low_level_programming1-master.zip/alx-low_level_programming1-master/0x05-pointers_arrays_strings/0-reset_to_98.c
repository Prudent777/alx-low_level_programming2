#include "main.h"
/**
 * reset_to_98 - use a pointer to change integer value
 * @n: parameter
 * Description - reset_to_98 resets the value of *n to 98
 */

void reset_to_98(int *n)
{
	*n = 98;
}
