pointer arrays strings
