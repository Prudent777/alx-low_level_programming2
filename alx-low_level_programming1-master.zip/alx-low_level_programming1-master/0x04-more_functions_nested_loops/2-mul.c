#include  "main.h"

/**
 * mul - multiply 2 integers
 * @a: int type number
 * @b: int type number
 * Return: result of multiplication
 */
int mul(int a, int b)
{
	return (a * b);
}
