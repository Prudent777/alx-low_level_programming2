more on nested loops
