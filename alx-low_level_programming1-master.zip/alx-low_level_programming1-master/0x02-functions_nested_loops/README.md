learrning nested loops
