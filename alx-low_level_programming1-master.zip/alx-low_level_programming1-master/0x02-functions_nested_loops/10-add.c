#include "main.h"

/**
 * add - add two intergers
 * @a: two interger arguments
 * @b: two integer arguments
 * Return: sum
 */
int add(int a, int b)
{
	return (a + b);
}
