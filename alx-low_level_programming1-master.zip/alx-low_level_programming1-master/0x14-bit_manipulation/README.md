binary_to_uint - Converts a binary string to an unsigned integer

print_binary - Prints an unsigned long int in binary

get_bit - gets the value of a bit at an index, starting from least bit at 0

set_bit - sets a bit to 1 at an index, starting from least bit at 0

clear_bit - sets a bit to 0 at an index, starting from the least bit at 0

get_endianness - returns 1 for little endian or 0 for big endian of a system

password - password for a crackme file
